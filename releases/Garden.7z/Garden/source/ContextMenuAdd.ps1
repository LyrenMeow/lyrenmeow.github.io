$key = (Get-Item -Path "HKCU:\Software\Classes\Directory").OpenSubKey("shell", $true).CreateSubKey("Garden")
$key.SetValue("MUIVerb", "Open in Garden")
$command = $key.CreateSubKey("command")
$command.SetValue("", ('cmd /c cd "' + $PSScriptRoot + '" && node index.js "%v"'))