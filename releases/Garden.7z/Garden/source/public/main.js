const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");
const fullscreenButton = document.getElementById("fullscreenButton");
const reloadButton = document.getElementById("reloadButton");
const indexField = document.getElementById("index");
const nameField = document.getElementById("filename");
const folderField = document.getElementById("folder");
const originField = document.getElementById("origin");
const countField = document.getElementById("picCount");
const resField = document.getElementById("res");
const maxHeightBox = document.getElementById("enableMaxHeight");
const img = document.querySelector("img");
const video = document.querySelector("video");
let container = img;
const keybinds = new Map();

img.addEventListener("click", nextButton.click);

const source = `/api/`;
/** @type {Array<{name: String, dirname:String,color: String}>} */
let pics = [];
let index = parseInt(location.hash.substring(1) - 1 || 0);
if (index < 0) {
	index = 0;
}

(async () => {
	const data = await fetch(source);
	const json = await data.json();
	originField.textContent = `Browsing ${json.origin}`;
	pics = json.pics;
	countField.textContent = `/ ${pics.length}`;
	if (index > 0) prevButton.disabled = false;
	if (index < pics.length - 1) nextButton.disabled = false;
	indexField.max = pics.length;
	setImage();
})();

function setImage() {
	const pic = pics[index];
	container.removeAttribute("alt");
	container.removeAttribute("src");
	container.hidden = true;
	if (
		["mp4", "webm", "avi", "mkv", "wmv", "flv"].includes(
			pic.name.toLowerCase().split(".").pop()
		)
	) {
		sauceButton.disabled = true;
		container = video;
	} else {
		sauceButton.disabled = false;
		container = img;
		if (!video.paused) video.pause();
	}

	container.removeAttribute("hidden");
	container.alt = pic.name;
	indexField.value = index + 1;
	if (pic.dirname) {
		pics[index].dirname = pic.dirname;
		container.src = `/img/${pic.dirname}/${pic.name}`;
	} else {
		container.src = "/img/" + pic.name;
	}
	container.style.borderColor = pic.color;
	nameField.textContent = pic.name;
	folderField.textContent = "📁" + pic.dirname;
	const u = new URL(location);
	u.hash = index + 1;
	location.replace(u);
	if (
		document.fullscreenElement !== null &&
		document.fullscreenElement !== container
	)
		container.requestFullscreen();
}

function colorImage(color) {
	container.style.borderColor = color;
	pics[index].color = color;
}

function patch(target) {
	return new Promise((resolve, reject) => {
		const p = fetch(`/img/${index}`, {
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(target),
		}).then((r) => {
			if (r.ok) r.json().then(resolve);
			else reject(r.statusText);
		});
	});
}

img.addEventListener("load", (event) => {
	resField.textContent = img.naturalHeight + " x " + img.naturalWidth;
});

video.addEventListener("loadeddata", (event) => {
	resField.textContent = video.videoHeight + " x " + video.videoWidth;
});

indexField.addEventListener("input", (event) => {
	const number = parseInt(indexField.value) - 1;
	if (isNaN(number) || !pics[number]) return;
	index = number;
	setImage();
});

prevButton.addEventListener("click", (event) => {
	index--;
	setImage();
	nextButton.disabled = false;
	if (index == 0) prevButton.disabled = true;
});

nextButton.addEventListener("click", (event) => {
	index++;
	prevButton.disabled = false;
	if (index >= pics.length - 1) nextButton.disabled = true;
	setImage();
});

fullscreenButton.addEventListener("click", (event) => {
	if (!document.fullscreenElement) container.requestFullscreen();
});

let timeoutId = null;

window.addEventListener("keydown", async (event) => {
	if (event.target.tagName === "INPUT") return;
	let p;
	switch (event.code) {
		case "ArrowRight":
			nextButton.click();
			break;
		case "ArrowLeft":
			prevButton.click();
			break;
		case "KeyF":
			if (document.fullscreenElement) document.exitFullscreen();
			else container.requestFullscreen();
	}
	const target = keybinds.get(event.code);
	if (target) {
		const { dirname, color } = target;
		p = patch(target);
		const t = new Promise((resolve, reject) => {
			clearTimeout(timeoutId);
			timeoutId = setTimeout(() => resolve(), 500);
		});
		p.then((r) => {
			pics[index].color = color;
			pics[index].dirname = dirname;
			pics[index].name = r.name;
			nameField.textContent = r.name;
			container.style.borderColor = color;
			folderField.textContent = "📁" + dirname;
		}).finally((r) => {});
		Promise.all([p, t])
			.then(() => {
				nextButton.click();
			})
			.catch((error) => {
				container.style.borderColor = "red green blue yellow";
				nameField.textContent = error;
			});
		event.preventDefault();
	}
});

fetch("/config.json").then((res) => {
	res.json().then((binds) => {
		for (const bind of binds) {
			keybinds.set(bind.code, bind);
		}
	});
});

document.body.addEventListener("mouseup", (event) => {
	const button = event.button;
	if (button === 3 || button === 4) {
		event.preventDefault();
		if (button === 3) {
			prevButton.click();
		} else {
			nextButton.click();
		}
	}
});

maxHeightBox.addEventListener("change", (event) => {
	for (const element of [img, video]) {
		element.style.maxHeight = maxHeightBox.checked ? null : "none";
	}
});

function fixFullscreen() {}
