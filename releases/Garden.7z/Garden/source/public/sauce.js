const sauceButton = document.getElementById("sauceButton");
const sauceSelect = document.getElementById("sauceSelect");
const sauceForm = document.getElementById("sauceForm");
const sauceInput = document.getElementById("sauceInput");

const sauceMap = new Map();
sauceMap.set("saucenao", ["https://saucenao.com/search.php", "file"]);
sauceMap.set("iqdb", ["https://iqdb.org/", "file"]);

for (const [key] of sauceMap) {
	const option = document.createElement("option");
	option.value = key;
	option.textContent = key;
	sauceSelect.append(option);
}

sauceButton.addEventListener("click", async (event) => {
	const [action, name] = sauceMap.get(sauceSelect.value);
	sauceForm.action = action;
	sauceInput.name = name;

	const canvas = document.createElement("canvas");
	canvas.height = img.naturalHeight;
	canvas.width = img.naturalWidth;
	const ctx = canvas.getContext("2d");
	ctx.drawImage(img, 0, 0);

	canvas.toBlob((blob) => {
		const filename = img.src.split("/").pop();
		const file = new File([blob], filename);
		const dt = new DataTransfer();
		dt.items.add(file);
		sauceInput.files = dt.files;
		sauceForm.submit();
	});
});
