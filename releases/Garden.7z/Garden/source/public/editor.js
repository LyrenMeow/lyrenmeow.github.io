const tbody = document.querySelector("tbody");
const addRowButton = document.getElementById("addRow");
const saveButton = document.getElementById("saveButton");
const backButton = document.getElementById("backButton");
const result = document.getElementById("result");

backButton.addEventListener("click", (event) => {
	history.back();
});

function addRow(code, dirname, color) {
	// create row
	const tr = tbody.insertRow();

	//create first cell & keyButton
	const keyTD = tr.insertCell();
	const keyButton = document.createElement("button");
	keyButton.textContent = code;
	keyButton.className = "keyButton";
	keyTD.append(keyButton);

	// add event listeners to keybutton
	keyButton.addEventListener("click", (event) => {
		keyButton.textContent = "";
	});
	keyButton.addEventListener("keydown", (event) => {
		event.preventDefault();
		if (["KeyF", "ArrowLeft", "ArrowRight"].includes(event.code)) return;
		for (const row of tbody.rows) {
			const element = row.cells[0].firstElementChild;
			if (element.textContent === event.code) element.textContent = "";
		}
		keyButton.textContent = event.code;
	});

	// create second cell, folderName
	const dirTD = tr.insertCell();
	dirTD.textContent = dirname;
	dirTD.contentEditable = true;
	dirTD.addEventListener("keydown", (event) => {
		if (event.key === "Enter") {
			event.preventDefault();
			dirTD.blur();
		}
	});

	// create third cell, colorInput
	const colorTD = tr.insertCell();
	const colorInput = document.createElement("input");
	colorInput.type = "color";
	colorInput.value = color;
	colorInput.className = "colorInput";
	colorTD.append(colorInput);

	// create fourth cell, deleteButton
	const deleteTD = tr.insertCell();
	const deleteButton = document.createElement("button");
	deleteButton.className = "deleteButton";
	deleteButton.textContent = "❌";
	deleteTD.append(deleteButton);

	//add event listeners to deleteButton
	deleteButton.addEventListener("click", (event) => {
		tr.remove();
	});
}

addRowButton.addEventListener("click", (event) =>
	addRow(null, "folder", "#00ff00")
);

// get editor settings and send to server
saveButton.addEventListener("click", (event) => {
	// set info text
	result.textContent = "saving...";
	// get editor settings
	const config = [];
	for (const row of tbody.rows) {
		const code = row.cells.item(0).textContent;
		const dirname = row.cells.item(1).textContent;
		const color = row.cells.item(2).firstElementChild.value;
		config.push({ code, dirname, color });
	}

	// send config to server
	fetch("/config.json", {
		method: "PATCH",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(config),
	}).then((res) => {
		// display response info and hide after 5 seconds
		if (res.ok) result.textContent = "config has been saved";
		setTimeout(() => (result.textContent = ""), 5000);
	});
});

// load and add rows to table
fetch("/config.json").then((res) => {
	res.json().then((rows) => {
		for (const row of rows) {
			const { code, dirname, color } = row;
			addRow(code, dirname, color);
		}
	});
});
