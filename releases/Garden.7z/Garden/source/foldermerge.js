const fs = require("fs");
const path = require("path");

const src = process.argv[2];

if (fs.existsSync(src)) {
	/** Directories inside src */
	const subdirs = fs
		.readdirSync(src, { withFileTypes: true })
		.filter((dirent) => {
			return dirent.isDirectory();
		});

	for (const subdir of subdirs) {
		/** Files inside each subdir */
		const targets = fs.readdirSync(path.join(src, subdir.name));

		// move each file to parent dir
		for (const target of targets) {
			let newName;
			let count = "";
			const ext = path.extname(target);

			do {
				// append number if name is take
				newName = path.basename(target, ext) + count + ext;
				if (count === "") count = 0;
				count++;
			} while (fs.existsSync(path.join(src, newName)));

			// move file with unique name
			fs.renameSync(
				path.join(src, subdir.name, target),
				path.join(src, newName)
			);
		}
		fs.rmdirSync(path.join(src, subdir.name));
	}
} else throw "target doesn't exist";
