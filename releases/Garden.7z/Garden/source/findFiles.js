const fs = require("fs");
const path = require("path");

const root = path.normalize(process.argv[2]);

function tree(dir) {
	const o = { "/": [] };
	const files = fs.readdirSync(dir);
	for (const file of files) {
		try {
			if (fs.statSync(path.join(dir, file)).isDirectory()) {
				o[file] = tree(path.join(dir, file));
			} else {
				o["/"].push(file);
			}
		} catch (error) {
			console.log(`Failed to read ` + path.join(dir, file));
		}
	}
	return o;
}

function shortText(dir) {
	let output = "";
	const files = fs.readdirSync(dir);
	for (const file of files) {
		try {
			if (fs.statSync(path.join(dir, file)).isDirectory()) {
				output += shortText(path.join(dir, file));
			} else {
				output += file + "\n";
			}
		} catch (error) {}
	}
	return output;
}

function longText(dir) {
	let output = "";
	const files = fs.readdirSync(dir);
	for (const file of files) {
		try {
			if (fs.statSync(path.join(dir, file)).isDirectory()) {
				output += longText(path.join(dir, file));
			} else {
				output += path.join(dir, file) + "\n";
			}
		} catch (error) {}
	}
	return output;
}

fs.writeFileSync("tree.json", JSON.stringify(tree(root)));
fs.writeFileSync("short.txt", shortText(root));
fs.writeFileSync("long.txt", longText(root));
