const express = require("express");
const fs = require("fs");
const path = require("path");
const types = require("./types");

const app = express();
const source = path.normalize(process.argv[2]);
const files = fs
	.readdirSync(source, { withFileTypes: true })
	.filter(
		(entry) =>
			entry.isFile() &&
			types.includes(entry.name.toLowerCase().split(".").pop())
	)
	.map((enty) => {
		return { name: enty.name, color: "", dirname: "" };
	})
	.sort((a, b) => a.name.localeCompare(b.name));

app.use(express.json());
app.use("/", express.static(path.join(__dirname, "public")));
app.use("/img/", express.static(source));

app.get("/api", (req, res) => {
	const out = {
		origin: source,
		pics: files,
	};
	res.json(out);
});

app.get("/config.json", (req, res) => {
	const config = path.join(source, "config.json");
	if (fs.existsSync(config)) res.sendFile(config);
	else res.json([]);
});

app.patch("/config.json", (req, res) => {
	fs.writeFileSync(
		path.join(source, "config.json"),
		JSON.stringify(req.body)
	);
	res.sendStatus(204);
});

/**@todo json */
app.patch("/img/:id", (req, res) => {
	const id = req.params.id;
	const { dirname, color } = req.body;
	const file = files[id];
	let newName;
	if (file.dirname !== req.body.dirname) {
		const targetDir = path.join(source, dirname);
		let count = "";

		const ext = path.extname(file.name);
		do {
			newName = path.basename(file.name, ext) + count + ext;
			if (count === "") count = 0;
			count++;
		} while (fs.existsSync(path.join(targetDir, newName)));
		let moved = file.dirname;
		if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir);
		fs.renameSync(
			path.join(source, moved, file.name),
			path.join(targetDir, newName)
		);
		files[id].color = color;
		files[id].dirname = dirname;
		files[id].name = newName;
	}
	res.json({ name: newName });
});

const port = 1080;
app.listen(port, () => {
	console.log(
		`Running on port ${port} with ${files.length} files from ${source}`
	);
});
