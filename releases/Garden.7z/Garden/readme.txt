-- HOW TO USE --

[Setup]

To use the Browse Feature:
- Install Node.js - https://nodejs.org/en/download/
- Run Node-setup.bat
- Add Garden to your context menu by using the "ContextMenuAdd" shortcut.
	- If that one throws an error at any point, try using the (Send to) version.

To use Folder Splitter:
- Install Java - https://adoptium.net/en-GB/download
- Run Shortcuts.exe

(You can also use the Folder.ico to set an icon for the Garden folder.)


[Browse Feature] - BROWSE AND SORT IMAGES WITHIN YOUR BROWSER

1. Right click a folder and select Garden
2. Open up a browser and go to localhost:1080
3. Press Hotkey Editor to setup your hotkeys and folder names. 
3.1 Press Save to confirm your changes
4. Press Back and browse pictures. Your hotkey config will be saved in the folder you are browsing with the name "config.json"

Usage:

Press left & right arrow keys to go back and forth.
Press F for fullscreen.
Press your custom hotkeys to sort the files into the folders you set up in the section 4.




[Folder Splitter] - SPLITS FOLDERS INTO EVEN AMOUNT OF FILES

NOTE: There is no confirmation box after you have chosen a folder.

1. Open up FolderSplitter
2. Type in how many files there will be per folder
3. Press Select Folder
4. Navigate into the folder you want to split

[Folder Merge] - MERGES SUBFOLDERS INTO ONE MAIN FOLDER

1. Open FolderMerge.exe
2. Paste in a folder which you want to merge
3. Press OK